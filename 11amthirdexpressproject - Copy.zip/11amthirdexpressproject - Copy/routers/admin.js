const router = require("express").Router();
const Banner = require("../models/banner");
const Adminregc = require("../controllers/adminregcontroller");
const bannerc = require("../controllers/bannercontroller");
const servicec = require("../controllers/servicecontroller");
const queryc = require("../controllers/querycontroller");
const contactc = require("../controllers/contactcontroller");
const testic = require("../controllers/testicontroller");
const multer = require("multer");

let storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/upload");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});

let upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 4 },
});

function handlelogin(req, res, next) {
  if (req.session.isAuth) {
    next();
  } else {
    res.redirect("/admin/");
  }
}

router.get("/", Adminregc.adminloginshow);
router.post("/loginrecord", Adminregc.adminlogincheck);
router.get("/dashboard", handlelogin, Adminregc.admindashboardshow);
router.get("/logout", Adminregc.adminlogout);
router.get("/banner", bannerc.adminbannershow);
router.get("/bannerupdate/:id", bannerc.adminbannerupdate);
router.post(
  "/bannerupdaterecord/:id",
  upload.single("img"),
  bannerc.adminbannerpostupdate
);
router.get("/service", servicec.adminserviceshow);
router.get("/serviceadd", servicec.adminserviceadd);
router.post(
  "/servicerecords",
  upload.single("img"),
  servicec.adminservicerecord
);
router.get("/servicedelete/:id", servicec.adminservicedelete);
router.get("/serviceupdate/:id", servicec.adminserviceupdate);
router.get("/query", queryc.adminqueryshow);
router.get("/queryform/:id", queryc.adminqueryform);
router.post(
  "/queryformrecors/:id",
  upload.single("attachment"),
  queryc.adminqueryrecord
);
router.post("/querysearch", queryc.querysearch);
router.get("/address", contactc.contactall);
router.get("/contactupdate/:id", contactc.contactupdate);
router.post(
  "/contactrecord/:id",
  upload.single("attachment"),
  contactc.contactrecords
);

module.exports = router;
