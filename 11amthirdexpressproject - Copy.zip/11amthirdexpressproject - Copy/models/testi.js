const mongoose = require("mongoose");

const testiSchema = mongoose.Schema({
  img: String,
  name: String,
  quote: String,
  Company: String,
});
module.exports = mongoose.model("testi", testiSchema);
