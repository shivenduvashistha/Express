const mongoose = require("mongoose");

const admiregSchema = mongoose.Schema({
  username: String,
  password: String,
});

module.exports = mongoose.model("adminreg", admiregSchema);
