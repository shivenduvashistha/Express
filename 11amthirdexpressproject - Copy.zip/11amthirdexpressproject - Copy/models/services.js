const mongoose = require("mongoose");

const serviceSchema = mongoose.Schema({
  img: String,
  title: String,
  desc: String,
  ldesc: String,
  postedDate: {
    type: Date,
    default: new Date(),
  },
  status: { type: String, default: "unpublish" },
});
module.exports = mongoose.model("service", serviceSchema);
