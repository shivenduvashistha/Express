const mongoose = require("mongoose");

const contactSchema = mongoose.Schema({
  add: String,
  tel: Number,
  mobile: Number,
  email: String,
  inst: String,
  facebook: String,
  twiter: String,
  link: String,
});

module.exports = mongoose.model("contact", contactSchema);
