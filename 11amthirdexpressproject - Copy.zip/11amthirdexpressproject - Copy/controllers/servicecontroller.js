const Services = require("../models/services");
const Contact = require("../models/contact");

exports.adminserviceshow = async (req, res) => {
  const record = await Services.find().sort({ postedDate: -1 });
  const totalServices = await Services.count();
  const totalPublish = await Services.count({ status: "publish" });
  const totalUnpublish = await Services.count({ status: "unpublish" });

  res.render("admin/service.ejs", {
    record,
    totalServices,
    totalPublish,
    totalUnpublish,
  });
};
exports.adminserviceadd = (req, res) => {
  res.render("admin/serviceform.ejs");
};
exports.adminservicerecord = async (req, res) => {
  const filename = req.file.filename;
  const { stitle, sdesc, sldesc } = req.body;
  const record = new Services({
    title: stitle,
    desc: sdesc,
    ldesc: sldesc,
    img: filename,
  });
  await record.save();
  //  console.log(record);
  res.redirect("/admin/service");
};
exports.adminservicedelete = async (req, res) => {
  const id = req.params.id;
  await Services.findByIdAndDelete(id);
  res.redirect("/admin/service");
};
exports.adminserviceupdate = async (req, res) => {
  const id = req.params.id;
  const record = await Services.findById(id);
  let newstatus = null;
  if (record.status == "unpublish") {
    newstatus = "publish";
  } else {
    newstatus = "unpublish";
  }
  await Services.findByIdAndUpdate(id, { status: newstatus });
  res.redirect("/admin/service");
};
exports.servicedetails = async (req, res) => {
  const id = req.params.id;
  const record = await Services.findById(id);
  const contactdata = await Contact.find();
  res.render("servicedetail.ejs", { record, contactdata });
};
