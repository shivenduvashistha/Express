const Query = require("../models/query");
const nodemailer = require("nodemailer");
const { findByIdAndUpdate } = require("../models/query");

exports.querypostdata = async (req, res) => {
  const { email, query } = req.body;
  const record = new Query({ email: email, query: query });
  await record.save();
  //console.log(record);
  res.redirect("/");
};
exports.adminqueryshow = async (req, res) => {
  const record = await Query.find();
  res.render("admin/query.ejs", { record });
};
exports.adminqueryform = async (req, res) => {
  const id = req.params.id;
  //console.log(id);
  const record = await Query.findById(id);
  res.render("admin/queryform.ejs", { record });
};
exports.adminqueryrecord = async (req, res) => {
  const id = req.params.id;

  const { eto, efrom, esubject, ebody } = req.body;
  const path = req.file.path;
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: "shivendu1816@gmail.com", // generated ethereal user
      pass: "fnugjfokzwonjynv", // generated ethereal password
    },
  });
  let info = await transporter.sendMail({
    from: efrom, // sender address
    to: eto, // list of receivers
    subject: esubject, // Subject line
    text: ebody, // plain text body
    attachments: [
      {
        path: path,
      },
    ],
  });
  await Query.findByIdAndUpdate(id, { status: "read" });
  res.redirect("/admin/query");
};
exports.querysearch = async (req, res) => {
  const { searchvalue } = req.body;
  const record = await Query.find({ status: searchvalue });
  res.render("admin/query.ejs", { record });
};
