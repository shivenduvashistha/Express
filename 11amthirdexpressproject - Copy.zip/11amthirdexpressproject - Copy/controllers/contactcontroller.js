const Contact = require("../models/contact");

exports.contactall = async (req, res) => {
  let record = await Contact.findOne();
  // console.log(record);
  res.render("admin/contact.ejs", { record });
};
exports.contactupdate = async (req, res) => {
  const id = req.params.id;
  const record = await Contact.findById(id);
  res.render("admin/contactupdate.ejs", { record });
};
exports.contactrecords = async (req, res) => {
  const id = req.params.id;
  const { add, tel, mob, instalink } = req.body;
  await Contact.findByIdAndUpdate(id, {
    add: add,
    tel: tel,
    mobile: mob,
    inst: instalink,
  });
  res.redirect("/admin/address");
};
