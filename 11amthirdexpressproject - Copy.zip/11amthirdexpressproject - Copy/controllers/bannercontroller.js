const Banner = require("../models/banner");
const Contact = require("../models/contact");

exports.adminbannershow = async (req, res) => {
  const record = await Banner.findOne();
  const contactdata = await Contact.findOne();
  res.render("admin/banner.ejs", { record, contactdata });
};
exports.adminbannerupdate = async (req, res) => {
  const id = req.params.id;
  const record = await Banner.findById(id);
  res.render("admin/bannerupdate.ejs", { record });
};
exports.adminbannerpostupdate = async (req, res) => {
  const id = req.params.id;
  const { btitle, bdesc, bldesc } = req.body;
  if (req.file) {
    const filename = req.file.filename;
    await Banner.findByIdAndUpdate(id, {
      title: btitle,
      desc: bdesc,
      ldesc: bldesc,
      img: filename,
    });
  } else {
    await Banner.findByIdAndUpdate(id, {
      title: btitle,
      desc: bdesc,
      ldesc: bldesc,
    });
  }
  res.redirect("/admin/banner");
};
exports.bannershow = async (req, res) => {
  const record = await Banner.findOne();
  const contactdata = await Contact.findOne();
  res.render("banner.ejs", { record, contactdata });
};
