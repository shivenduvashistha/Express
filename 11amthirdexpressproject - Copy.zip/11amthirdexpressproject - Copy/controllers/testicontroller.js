const Testi = require("../models/testi");
const Contact = require("../models/contact");

exports.showtesti = async (req, res) => {
  contactdata = await Contact.find();
  res.render("testi.ejs", { contactdata });
};

exports.testirecords = async (req, res) => {
  const { quotes, cname } = req.body;
  //console.log(req.file);
  const filename = req.file.filename;
  const record = new Testi({ quote: quotes, name: cname, img: filename });
  await record.save();
  res.redirect("/");
};

exports.adminshow = async (req, res) => {
  const record = await Testi.find();
  res.render("admin/testi.ejs", { record });
};
