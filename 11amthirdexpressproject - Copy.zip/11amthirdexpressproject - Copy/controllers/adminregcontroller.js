const Adminreg = require("../models/adminreg");

exports.adminloginshow = (req, res) => {
  res.render("admin/login.ejs");
};

exports.adminlogincheck = async (req, res) => {
  const { us, pass } = req.body;
  const record = await Adminreg.findOne({ username: us });
  //console.log(record);
  if (record !== null) {
    if (record.password == pass) {
      req.session.isAuth = true;
      res.redirect("/admin/dashboard");
    } else {
      res.redirect("/admin/");
    }
  } else {
    res.redirect("/admin/");
  }
};
exports.admindashboardshow = (req, res) => {
  res.render("admin/dashboard.ejs");
};

exports.adminlogout = (req, res) => {
  req.session.destroy();
  res.redirect("/admin/");
};
